/* eslint-disable eqeqeq */
/* eslint-disable camelcase */
import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/home',
      component: () => import('@/pages/home'),
      children: [
        {
          path: '/home/index',
          component: () => import('@/pages/index')
        },
        {
          path: '/home/applicationList',
          component: () => import('@/pages/applicationList')
        },
        {
          path: '/home/applicationtAntistop',
          component: () => import('@/pages/applicationtAntistop')
        },
        {
          path: '/home/applicationNameRule',
          component: () => import('@/pages/applicationNameRule')
        },
        {
          path: '/home/applicationCache',
          component: () => import('@/pages/applicationCache')
        },
        {
          path: '/home/setting',
          component: () => import('@/pages/setting')
        },
        {
          path: '/home',
          redirect: '/home/index'
        }
      ]
    },
    {
      path: '/login',
      component: () => import('@/pages/login')
    },
    {
      path: '/register',
      component: () => import('@/pages/register')
    },
    {
      path: '/',
      redirect: '/home'
    }
  ]
})

router.beforeEach((to, from, next) => {
  var user_id = localStorage.getItem('user_id')

  if (user_id) {
    next()
  } else {
    if (to.path == '/login' || to.path == '/register') {
      next()
    } else {
      next('/login')
    }
  }
})

// eslint-disable-next-line semi
export default router;
