<template>
    <div>
        <el-breadcrumb separator="/">
            <el-breadcrumb-item >首页</el-breadcrumb-item>
            <el-breadcrumb-item >应用关键词</el-breadcrumb-item>
        </el-breadcrumb>
    <!--region table 表格-->
     <i-table :list="list"
    :options="options"
    :columns="columns"
    :operates="operates"
  >
 </i-table>

    <el-dialog title="编辑" :visible.sync="visible" width="300" :before-close="handleClose">
      <el-form :label-position="'left'" label-width="60px">
        <el-form-item label="编号">
          <el-input type="text" v-model="currentItem.id" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="标题">
          <el-input type="text" v-model="currentItem.title" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="状态">
           <el-radio-group v-model="currentItem.state">
                <el-radio :label="0">上架</el-radio>
                <el-radio :label="1">下架</el-radio>
                <el-radio :label="2">审核中</el-radio>
            </el-radio-group>
        </el-form-item>
      </el-form>

      <span slot="footer" class="dialog-footer">
        <el-button @click="visible = false">取 消</el-button>
        <el-button type="primary" @click="handleConfirm">确 定</el-button>
      </span>
    </el-dialog>
    </div>
</template>
<script>
  import iTable from '../components/table'

 export default {
  components: {iTable},
  data () {
   return {
       currentItem:{
           id:"",
           title:"",
           state:""
       },
    list: [
       {
        id: 24,
        title: '编号3',
        state:0
       },
       {
        id: 23,
        title: '编号3',
        state:1
       },
       {
        id: 23,
        title: '编号3',
        state:2
       },
       {
        id: 2,
        title: '编号3',
        state:0
       },
       {
        id: 28,
        title: '编号3',
        state:1
       },
       {
        id: 2444,
        title: '编号3',
        state:1
       },
    ], // table数据
    options: {
     stripe: false, // 是否为斑马纹 table
     loading: false, // 是否添加表格loading加载动画
     highlightCurrentRow: false, // 是否支持当前行高亮显示
     mutiSelect: false, // 是否支持列表项选中功能
    }, // table 的参数
    columns: [
     {
      prop: 'id',
      label: '编号',
      align: 'center',
      hasSort:true
     },
     {
      prop: 'title',
      label: '标题',
      align: 'center',
    //   formatter: (row, column, cellValue) => {
    //    return `<span style="white-space: nowrap;color: dodgerblue;">${row.title}</span>`
    //   }
     },
     {
      prop: 'state',
      label: '状态',
      align: 'center',
      render: (h, params) => {
       return h('span', {
       props: {} // 组件的props
       }, params.row.state === 0 ? '上架' : params.row.state === 1 ? '下架' : '审核中')
      }
     },
 
    ], // 需要展示的列
    operates: {
     width: 150,
     list: [
      {
       id:'1',
       label: '编辑',
       type: 'warning',
       show: true,
       plain: true,
       disabled: false,
       method: (index, row) => {
        this.handleEdit(index, row)
       }
      },
      {
       id:'2',
       label: '删除',
       type: 'danger',
       show: true,
       plain: false,
       disabled: false,
       method: (index, row) => {
        this.handleDel(index, row)
       }
      }
     ]
    }, // 列操作按钮
    visible: false
   }
  },
  methods: {
   // 编辑
   handleEdit (index, row) {
    console.log(' index:', index)
    console.log(' row:', row)
    this.visible = true
    this.currentItem = {
        id:row.id,
        title:row.title,
        state:row.state
    }
    console.log(this.currentItem.state)
   },
   handleConfirm(){
       console.log(this.currentItem)
       this.visible = false
   },
   handleClose() {
      this.visible = false;
    },
   // 删除
   handleDel (index, row) {
    console.log(' index:', index)
    console.log(' row:', row)
    this.list.splice(index, 1);
   }
  }
 }
</script>
<style scoped>

</style>

