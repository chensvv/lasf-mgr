<template>
  <div class="table">
    <el-breadcrumb separator="/">
      <el-breadcrumb-item>首页</el-breadcrumb-item>
      <el-breadcrumb-item>应用列表</el-breadcrumb-item>
    </el-breadcrumb>
    <el-button class="success" size="mini" @click="handleAdd()">添加</el-button>
    <el-form :inline="true" ref="searchItem" :model="searchItem" class="demo-form-inline search_box" size="mini">
      <el-form-item label="应用名" prop="applicationName">
        <el-input v-model="searchItem.applicationName"></el-input>
      </el-form-item>
      <el-form-item label="来自于" prop="from">
        <el-select v-model="searchItem.from" placeholder="--">
          <el-option label="联想" value="联想"></el-option>
          <el-option label="百度" value="百度"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="开始时间" prop="refreshTime">
          <el-date-picker type="date" placeholder="选择日期" v-model="searchItem.refreshTime" style="width: 100%;"></el-date-picker>
      </el-form-item>
      <el-form-item label="结束时间" prop="putTime">
          <el-date-picker type="date" placeholder="选择日期" v-model="searchItem.putTime" style="width: 100%;"></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">查询</el-button>
        <el-button @click="resetForm('searchItem')">重置</el-button>
      </el-form-item>
    </el-form>
    <div class="table-box">
      <i-table :list="list.slice((currentPage-1)*pageSize,currentPage*pageSize)" :options="options" :columns="columns" :operates="operates"></i-table>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage"
        :page-sizes="pageSizes"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalCount"
      ></el-pagination>
    </div>

    <el-dialog title="编辑" :visible.sync="editVisible" width="300" :before-close="editHandleClose">
      <el-form :label-position="'left'" label-width="80px">
        <el-form-item label="应用名">
          <el-input type="text" v-model="currentItem.applicationName" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="类别">
          <el-input type="text" v-model="currentItem.classnames" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="平台">
          <el-input type="text" v-model="currentItem.platform" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="费用">
          <el-input type="text" v-model="currentItem.cost" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="积分">
          <el-input type="text" v-model="currentItem.integral" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="下载次数">
          <el-input type="text" v-model="currentItem.downloads" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="来自">
          <el-input type="text" v-model="currentItem.from" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="editVisible = false">取 消</el-button>
        <el-button type="primary" @click="editHandleConfirm">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog title="新增" :visible.sync="addVisible" width="300" :before-close="addHandleClose">
      <el-form :label-position="'left'" label-width="80px">
        <el-form-item label="应用名">
          <el-input type="text" v-model="addList.applicationName" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="类别">
          <el-input type="text" v-model="addList.classnames" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="平台">
          <el-input type="text" v-model="addList.platform" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="费用">
          <el-input type="text" v-model="addList.cost" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="积分">
          <el-input type="text" v-model="addList.integral" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="下载次数">
          <el-input type="text" v-model="addList.downloads" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="来自">
          <el-input type="text" v-model="addList.from" auto-complete="off"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addVisible = false">取 消</el-button>
        <el-button type="primary" @click="addHandleConfirm">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
let moment = require("moment");
import iTable from "@/components/table";
import {formatDate} from '@/utils/format.js'
export default {
  name: "applicationlist",
  components: { iTable },
  data() {
    return {
      list: [],
      currentItem: {//修改数据组
        applicationName: "",
        classnames: "",
        platform: "",
        cost: "",
        integral: "",
        downloads: "",
        from: ""
      },
      addList: {//添加数据组
        applicationName: "",
        classnames: "",
        platform: "",
        cost: "",
        integral: "",
        downloads: "",
        from: ""
      },
      searchItem:{//搜索数据组
        applicationName:"",
        from:"",
        refreshTime:"",
        putTime:""
      },
      columns: [
        {
          prop:"id",
          label: "序号",
          align: "center",
          width: 80,
          hasSort:true,
        },
        {
          prop: "applicationName",
          label: "应用名",
          align: "center",
          width: 100
        },
        {
          prop: "classnames",
          label: "类别",
          align: "center",
          width: 120
        },
        {
          prop: "platform",
          label: "平台",
          align: "center",
          width: 100
        },
        {
          prop: "cost",
          label: "费用",
          align: "center",
          width: 80
        },
        {
          prop: "integral",
          label: "积分",
          align: "center",
          width: 80
        },
        {
          prop: "downloads",
          label: "下载次数",
          align: "center",
          width: 100
        },
        {
          prop: "from",
          label: "来自",
          align: "center",
          width: 100
        },
        {
          prop: "refreshTime",
          label: "更新时间",
          align: "center",
          render: (h, params)=>{
            var timer = parseInt(params.row.refreshTime)
              return h('span',
              formatDate(new Date(timer), 'yyyy-MM-dd'))
          }
        },
        {
          prop: "putTime",
          label: "入库时间",
          align: "center",
          render: (h, params)=>{
            var timer = parseInt(params.row.refreshTime)
              return h('span',
              formatDate(new Date(timer), 'yyyy-MM-dd hh:mm'))
          }
        }
      ],
      options: {
        stripe: false, // 是否为斑马纹 table
        loading: true, // 是否添加表格loading加载动画
        highlightCurrentRow: false, // 是否支持当前行高亮显示
        mutiSelect: false, // 是否支持列表项选中功能
        border:false     //是否显示纵向边框
      },
      operates: {
        width: 120,
        show: false,
        list: [
          {
            id: "1",
            label: "编辑",
            show: true,
            plain: true,
            disabled: false,
            method: (index, row) => {
              this.handleEdit(index, row);
            }
          },
          {
            id: "2",
            label: "删除",
            show: true,
            plain: false,
            disabled: false,
            method: (index, row) => {
              this.handleDel(index, row);
            }
          }
        ]
      }, // 列操作按钮
      editVisible: false,
      addVisible: false,
      // 分页
      currentPage: 1, //默认显示第几页
      pageSize: 10,   //默认每页条数
      pageSizes:[10, 20, 30],
      totalCount:1     // 总条数
    };
  },
  created() {
    this.getList();
  },
  methods: {
    dateFormat(row, column) {
      const date = row[column.property];
      if (date == undefined) {
        return "";
      }
      return moment(date).format("YYYY-MM-DD ");
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    onSubmit(){
      console.log(this.searchItem)
    },
    handleSizeChange(val) {
      this.pageSize = val;
      this.currentPage = 1
      console.log(this.pageSize)
    },
    handleCurrentChange(val) {
      this.currentPage = val
      console.log(`当前页: ${val}`);
    },
    handleEdit(index, row) {
      console.log(index, row);
      this.editVisible = true;
      this.currentItem = {
        applicationName: row.applicationName,
        classnames: row.classnames,
        platform: row.platform,
        cost: row.cost,
        integral: row.integral,
        downloads: row.downloads,
        from: row.from
      };
    },
    handleDel(index, row) {
      console.log(row.id);
      console.log(index)
      this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
          this.$http.post("./list", {
              id: row.id
            }).then(res => {
              console.log(res);
            });
        }).catch(() => {
          console.log("no");
        });
    },
    editHandleClose() {
      this.editVisible = false;
      
    },
    addHandleClose(){
      this.addVisible = false
    },
    editHandleConfirm() {
      console.log(this.currentItem)
      this.editVisible = false;
    },
    handleAdd(){
      this.addVisible = true
    },
    addHandleConfirm() {
      console.log(this.addList)
      this.visible = false;
    },
    getList() {
      this.$http.get("/api/data").then(res => {
        this.list = res.data;
        this.totalCount = res.data.length
        this.options.loading = false;
      });
    }
  }
};
</script>

<style scoped>
</style>
