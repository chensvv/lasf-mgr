<template>
    <div>
        <el-breadcrumb separator="/">
            <el-breadcrumb-item >首页</el-breadcrumb-item>
            <el-breadcrumb-item >应用别名规则</el-breadcrumb-item>
        </el-breadcrumb>

    </div>
</template>