<template>
    <div class="index">
        <el-breadcrumb separator="/">
            <el-breadcrumb-item >首页</el-breadcrumb-item>
            <!-- <el-breadcrumb-item ></el-breadcrumb-item> -->
        </el-breadcrumb>


    </div>
</template>
