<template>
    <el-menu mode="vertical" :default-active="$route.path" :router="isRouter">
        
        <el-menu-item index="/home/index">
            <i class="el-icon-location"></i>
			<span>首页</span>
        </el-menu-item>
        <el-submenu index="1">
            <template slot="title">
                <i class="el-icon-date"></i>
                <span>数据管理</span>
            </template>

            <el-menu-item index="/home/applicationList">
                <i class="el-icon-star-on"></i>
                <span>应用列表</span>
            </el-menu-item>
            <el-menu-item index="/home/applicationtAntistop">
                <i class="el-icon-circle-check"></i>
                <span>应用关键词</span>
            </el-menu-item>
            <el-menu-item index="/home/applicationNameRule">
                <i class="el-icon-service"></i>
                <span>应用别名规则</span>
            </el-menu-item>
            <el-menu-item index="/home/applicationCache">
                <i class="el-icon-service"></i>
                <span>应用缓存</span>
            </el-menu-item>
        </el-submenu>

        <el-menu-item index="/home/setting">
            <i class="el-icon-setting"></i>
			<span>设置</span>
        </el-menu-item>
    </el-menu>    
</template>

<script>
export default {
    data(){
        return {
            isRouter:true,
            key:'/home/index'
        }
    }
}
</script>

<style>

</style>
