/* eslint-disable no-undef */
import Mock from 'mockjs'
// 模拟数据列表
const count = 50
let dataList = []
for (let i = 0; i < count; i++) {
  let arr = {
    id: Mock.Random.increment(),
    applicationName: Mock.Random.csentence(2, 3),
    classnames: Mock.Random.csentence(2, 5),
    refreshTime: Mock.mock('@date(T)'),
    state: Mock.Random.integer(0, 2),
    platform: Mock.Random.last(3, 5),
    downloads: Mock.Random.integer(100, 9999),
    cost: Mock.Random.integer(100, 9999),
    integral: Mock.Random.float(1, 9, 1, 1),
    from: Mock.Random.last(3, 5),
    putTime: Mock.mock('@date(T)')
  }
  dataList.push(arr)
}

Mock.mock('/api/data', /post|get/i, dataList)
